/*
 adview openapi ad-WQ.
 */

#import "AdViewViewImpl.h"
#import "AdViewConfig.h"
#import "AdViewAdNetworkConfig.h"
#import "AdViewDelegateProtocol.h"
#import "AdViewLog.h"
#import "AdViewAdNetworkAdapter+Helpers.h"
#import "AdViewAdNetworkRegistry.h"
#import "AdViewAdapterWQ.h"
#import "AdViewExtraManager.h"

@interface AdViewAdapterWQ ()
@end

@implementation AdViewAdapterWQ

+ (AdViewAdNetworkType)networkType {
    return AdViewAdNetworkTypeWQ;
}

+ (void)load {
	if(NSClassFromString(@"KOpenAPIAdView") != nil) {
		[[AdViewAdNetworkRegistry sharedRegistry] registerClass:self];
	}
}

- (int)OpenAPIAdType {
    return KOPENAPIADTYPE_WQMOBILE;
}

- (NSString *)appId {
	NSString *apID;
	if ([self.adViewDelegate respondsToSelector:@selector(WQAppIDString)]) {
		apID = [self.adViewDelegate WQAppIDString];
	}
	else {
		apID = self.networkConfig.pubId;
	}
    
	return apID;
	//return @"123456789";
}

- (NSString*)appPwd {
	NSString *idStr;
	if ([self.adViewDelegate respondsToSelector:@selector(WQPublisherIDString)]) {
		idStr = [self.adViewDelegate WQPublisherIDString];
	}
	else {
		idStr = self.networkConfig.pubId2;
	}
    
	return idStr;
}

@end