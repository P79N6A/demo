/*
 
 Adview .
 
 */

#import "AdViewAdapterOpenAPI.h"
#import "KOpenAPIAdView.h"


/*Adview openapi ad -- WQ.*/

@interface AdViewAdapterWQ : AdViewAdapterOpenAPI {
    
}

+ (AdViewAdNetworkType)networkType;

@end