//
//  AppDelegate.h
//  36admob
//
//  Created by FEIWU888 on 2017/10/25.
//  Copyright © 2017年 FEIWU888. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

