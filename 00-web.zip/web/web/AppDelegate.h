//
//  AppDelegate.h
//  web
//
//  Created by czljcb on 2018/3/29.
//  Copyright © 2018年 czljcb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

