//
//  TTZData.h
//  9*9
//
//  Created by Jay on 2018/4/9.
//  Copyright © 2018年 Jay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTZData : NSObject
+ (UIImage *)bgImage;
@end
