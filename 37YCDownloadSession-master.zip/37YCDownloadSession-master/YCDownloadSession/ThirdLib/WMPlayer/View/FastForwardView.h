//
//  FastForwardView.h
//  WMPlayer
//
//  Created by 郑文明 on 16/10/26.
//  Copyright © 2016年 郑文明. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FastForwardView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *sheetStateImageView;
@property (weak, nonatomic) IBOutlet UILabel *sheetTimeLabel;
@end
