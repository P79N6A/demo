//
//  PlayerViewController.h
//  YCDownloadSession
//
//  Created by wz on 2017/9/30.
//  Copyright © 2017年 onezen.cc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YCDownloadItem.h"

@interface PlayerViewController : UIViewController

@property (nonatomic, strong) YCDownloadItem *playerItem;
@end
