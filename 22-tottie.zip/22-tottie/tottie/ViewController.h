//
//  ViewController.h
//  tottie
//
//  Created by czljcb on 2017/8/27.
//  Copyright © 2017年 czljcb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

